package com.wipro.MiniProject.Service;

import com.wipro.MiniProject.Model.Expense;
import com.wipro.MiniProject.Repository.ExpenseRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService {
    @Autowired
    private ExpenseRepo expenseRepo;

    public List<Expense> findAll() {
        return expenseRepo.findAll();
    }

    public Expense save(Expense expense) {
        return expenseRepo.save(expense);
    }

    public void deleteById(Long id) {
        expenseRepo.deleteById(id);
    }
}
