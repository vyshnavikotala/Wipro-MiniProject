package com.wipro.MiniProject.Service;

import com.wipro.MiniProject.Model.Trip;
import com.wipro.MiniProject.Repository.TripRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TripService {
    @Autowired
    private TripRepo tripRepo;

    public List<Trip> findAll() {
        return tripRepo.findAll();
    }

    public Trip save(Trip trip) {
        return tripRepo.save(trip);
    }

    public void deleteById(Long id) {
        tripRepo.deleteById(id);
    }
}
