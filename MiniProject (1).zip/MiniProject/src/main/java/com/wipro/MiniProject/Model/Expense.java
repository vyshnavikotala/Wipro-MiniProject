package com.wipro.MiniProject.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data

@Entity
public class Expense {

    @Id
   private Long id;//pk
   private  String Description;
   private double amount;
    @ManyToOne
    @JoinColumn(name = "trip_Id")
    private Trip trip;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
