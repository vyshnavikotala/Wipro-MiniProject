package com.wipro.MiniProject.Repository;

import com.wipro.MiniProject.Model.Trip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TripRepo extends JpaRepository <Trip,Long>{
}
