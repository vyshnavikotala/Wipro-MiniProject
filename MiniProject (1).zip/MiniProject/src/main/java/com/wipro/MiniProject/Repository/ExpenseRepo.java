package com.wipro.MiniProject.Repository;

import com.wipro.MiniProject.Model.Expense;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExpenseRepo extends JpaRepository<Expense,Long> {
}
